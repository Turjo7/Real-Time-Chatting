// Initialize Firebase
var config = {
	// Config from Firebase Console
  apiKey: "AIzaSyDmf45jInhjo4DPi1o8r-rg3C1k172YazU",
  authDomain: "real-time-chatting-5e1cd.firebaseapp.com",
  databaseURL: "https://real-time-chatting-5e1cd.firebaseio.com",
  projectId: "real-time-chatting-5e1cd",
  storageBucket: "real-time-chatting-5e1cd.appspot.com",
  messagingSenderId: "581747804043",
  appId: "1:581747804043:web:f3d78490fa2a5dea88d18e",
  measurementId: "G-77WGVD6Z5Q"

};

firebase.initializeApp(config);

// Initialize Cloud Firestore through Firebase
var db = firebase.firestore();

// Disable deprecated features
db.settings({
	timestampsInSnapshots: true
});
